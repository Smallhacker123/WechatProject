//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    array: [{
      mode: 'center'
    }],
    english: []
  },
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    var that = this//不要漏了这句，很重要

    wx.request({
      url: 'https://open.iciba.com/dsapi',
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        //将获取到的json数据，存在名字叫zhihu的这个数组中
        that.setData({
          english: res.data
          //res代表success函数的事件对，data是固定的，stories是是上面json数据中stories

        })
      }
    })
  },
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  onShareAppMessage: function () {
    return {
      title: '每日一句'
    }
  }
})