// pages/authorize/authorize.js
const app = getApp()
Page({
data:{
  canIUser:wx.canIUse('button.open.getUserInfo'),
},
onLoad:function(options){
  var that=this;
  wx.getSetting({
    success: function (res) {
      if (res.authSetting['scope.userInfo'])
      wx.getUserInfo({
        success:function(res){
          app.globalData.getUserInfo=res.userInfo;
          //用户已经登入
          wx.switchTab({
            url: '/pages/index/index',
          })
        }
      })
  }
  })
  
},
  bindGetUserInfo:function(e){
  console.log(e);
  var that=this;
  if(e.detail.userInfo){
    console.log(e.detail.userInfo);
    app.globalData.userInfo=e.detail.userInfo;
    wx.navigateBack({
      url:"/pages/index/index",
    })
  }
  else{
    wx.showModal({
      title: '警告',
      content: '你点击了拒绝授权，将无法进入小程序，请授权之后再进入',
    })
  }
}
})