//app.js
App({
  onLaunch: function () {
    // 展示本地存储能力

  },
  getExpressInfo: function (nu, cb) {//获取快递信息,传入一个快递单号以及一个方法
    var thispage = this;
    wx.request({
      url: 'https://route.showapi.com/64-19?showapi_appid=86771&showapi_sign=429d865454794533812b1684013d685a&com=auto&nu=' + nu,
      data: {
        x: '',
        y: ''
      },
     
      header: {
        'content-type': 'application/json' // 默认值
      },
      success(res) {
        //console.log(res.data.showapi_res_body.flag)
        cb(res.data)
      }
    })
  },
  onShareAppMessage: function () {
    return {
      title: '快递单号查询'
    }
  },
  globalData: {
    userInfo: null
  }
})