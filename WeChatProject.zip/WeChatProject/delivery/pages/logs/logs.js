//index.js
//获取应用实例
const app = getApp()
Page({
  data: {
    Liuhecai: null,
    Number: null,
    Number: null,
    check:null
  },
  onLoad: function () {
    var that = this;
    //显示一个加载状态
    wx.showToast({
      title: '玩命加载中...',
      icon: 'loading',
      duration: 1000
    }) 
    wx.request({
      url: 'https://way.jd.com/showapi/multi?code=hk6&count=24&appkey=9aa58cda47887b64c018f1df8cebc247',
      headers: {
        'Content-Type': 'application/json'
      },
      success: function (res) {
        //截取时间格式
        var getDateLength = res.data.result.showapi_res_body.result[0].time.length;
        var getDateLength1 = res.data.result.showapi_res_body.result[0].expect.length;
        for (var i = 0; i < getDateLength + 5; i++) {//这里减7是因为循环12次，但是getDateLength为19
          if (res.data.result.showapi_res_body.result[i].time.length <= 20) {
            res.data.result.showapi_res_body.result[i].time = res.data.result.showapi_res_body.result[i].time.substring(0, 10);
          }
        }
        //截取时间格式修改期数
        for (var i = 0; i < getDateLength1 + 17; i++) {//这里加5是因为循环12次，但是getDateLength1为7
          if (res.data.result.showapi_res_body.result[i].expect.length <= 20) {
            res.data.result.showapi_res_body.result[i].expect = res.data.result.showapi_res_body.result[i].expect.substring(4, 7);
          }
        }
        var number0 = []  //定义一个装号码的数组
        for (var i = 0; i < getDateLength1 + 17; i++) {//处理数据这里需要遍历12次
          var number1 = res.data.result.showapi_res_body.result[i].openCode
          var number2 = number1.split("+")
          number0.push(number2)
        }
        var number4 = []
        for (var i = 0; i < getDateLength1 + 17; i++) {//处理数据这里需要遍历12次
          var number3 = number0[i][0].split(',')
          number4.push(number3)

        }
        //将获取到的json数据，存在名字叫Liuhecai的这个数组中
        that.setData({
          Liuhecai: res.data,
          Number: number0,
          Number0: number4
          //res代表success函数的事件对，data是固定的，stories是是上面json数据中stories
        })
        if (that.data.Liuhecai.charge == true) {//这里只能填两个==
          that.setData({ check: true })//用thispage.data取到expressInfo数据
        } else {
          that.setData({ check: false })
        }
      }
    })
  },
  //下拉刷新事件
  onPullDownRefresh:function(){
    var that=this;
    that.onLoad();
    wx.stopPullDownRefresh()//下拉刷新成功时关闭
  },
  /*
  //上拉加载事件
  onReachBottom:function(event){
    var that=this;
    console.log("Hello");
    that.onLoad();
  },*/
  onShareAppMessage: function (options) {
    var that=this;
    var shareObj = {
      title: '六合彩开奖结果查询',
      success: function (res) {
        // 转发成功之后的回调
        if (res.errMsg == 'shareAppMessage:ok') {
          that.onLoad()
        }
      },
      fail: function () {
        　　　　　　// 转发失败之后的回调
        　　　　　　if (res.errMsg == 'shareAppMessage:fail cancel') {
          　　　　　　　　// 用户取消转发
        　　　　　　} else if (res.errMsg == 'shareAppMessage:fail') {
          　　　　　　　　// 转发失败，其中 detail message 为详细失败信息
        　　　　　　}
      　　　　},
    }
  return shareObj;
  }
})
