//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    expressNu: null,//用来保存输入框的数据
    expressInfo: null,
    text: '快递信息尚未录入系统,或者快递单号出错',
    Check: null
  },
  /*想设计一个定时器
  timeOut: function(){
    number = this.data.expressNu;
    setTimeout(function () {
      console.log("延迟调用============")
      var thispage = this;
      console.log(number)

    }, 2000)
  },
  */
  btnClick: function () {
    var thispage = this;
    app.getExpressInfo(this.data.expressNu, function (data) {
      thispage.setData({ expressInfo: data })
      if (thispage.data.expressInfo.showapi_res_body.flag == true ) {//这里只能填两个==
        thispage.setData({ check: false })//用thispage.data取到expressInfo数据
      } else {
        thispage.setData({ check: true })
      }
    });
    //显示一个加载状态

    //console.log(this.data.expressInfo)

    wx.showToast({
      title: '玩命加载中...',
      icon: 'loading',
      duration: 1000,
    })
  },
  scanCode: function () {
    var that = this;
    wx.scanCode({
      success: (res) => {
        console.log(res)
        if (res.result) {
          //self.searchExpress(util.trim(res.result));
          that.setData({
            expressNu: res.result
          })
          that.btnClick();//调用按钮函数
        } else {
          wx.showModal({
            title: '提示',
            content: '快递单号不能为空！',
            showCancel: false,
            success: function (res) {
              if (res.confirm) {
                self.setData({
                  focus: true
                })
              }
            }
          })
        }
      }
    })
  },

  input: function (e) {
    this.setData({ expressNu: e.detail.value })
  },
  onShareAppMessage: function () {
    return {
      title: '快递单号查询'
    }
  }
})
